#include "parsers.h"

namespace CPUdata {
    class CPUDataParser : Parsers::parser {

    }
}